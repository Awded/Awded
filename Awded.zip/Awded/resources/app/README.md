# Awded
Visual overlay for deaf and hard of hearing players to visualize direction of audio during gameplay, for increased situational awareness.
